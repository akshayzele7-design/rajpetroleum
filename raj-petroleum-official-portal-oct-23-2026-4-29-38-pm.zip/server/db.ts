import fs from 'node:fs';
import path from 'node:path';
import initSqlJs, { Database as SqlDatabase } from 'sql.js';
import bcrypt from 'bcryptjs';

const DATA_DIR = path.resolve(process.cwd(), 'data');
const DB_FILE = path.join(DATA_DIR, 'raj_petroleum.sqlite');

let sqlDb: SqlDatabase | null = null;

// Ensure data directory exists
if (!fs.existsSync(DATA_DIR)) {
  fs.mkdirSync(DATA_DIR, { recursive: true });
}

// Persist SQLite database to disk
export function saveDbToDisk(): void {
  if (!sqlDb) return;
  try {
    const data = sqlDb.export();
    const buffer = Buffer.from(data);
    fs.writeFileSync(DB_FILE, buffer);
  } catch (err) {
    console.error('Failed to save database to disk:', err);
  }
}

// Run parameterized query that returns multiple rows
export function queryAll<T = any>(sql: string, params: any[] = []): T[] {
  if (!sqlDb) throw new Error('Database not initialized');
  const stmt = sqlDb.prepare(sql);
  try {
    stmt.bind(params);
    const results: T[] = [];
    while (stmt.step()) {
      results.push(stmt.getAsObject() as T);
    }
    return results;
  } finally {
    stmt.free();
  }
}

// Run parameterized query that returns a single row
export function queryOne<T = any>(sql: string, params: any[] = []): T | null {
  const rows = queryAll<T>(sql, params);
  return rows.length > 0 ? rows[0] : null;
}

// Run insert/update/delete statement with params
export function execute(sql: string, params: any[] = []): { changes: number; lastInsertRowid: number } {
  if (!sqlDb) throw new Error('Database not initialized');
  sqlDb.run(sql, params);
  const info = queryOne<{ id: number }>('SELECT last_insert_rowid() AS id');
  saveDbToDisk();
  return {
    changes: 1,
    lastInsertRowid: info?.id || 0,
  };
}

// Initialize database with tables and initial seed
export async function initDatabase(): Promise<void> {
  const SQL = await initSqlJs();

  if (fs.existsSync(DB_FILE)) {
    try {
      const fileBuffer = fs.readFileSync(DB_FILE);
      sqlDb = new SQL.Database(fileBuffer);
      console.log('[Database] Loaded existing database from disk:', DB_FILE);
    } catch (e) {
      console.warn('[Database] Failed to read existing db file, initializing new one:', e);
      sqlDb = new SQL.Database();
    }
  } else {
    sqlDb = new SQL.Database();
    console.log('[Database] Initialized new relational database at:', DB_FILE);
  }

  // Enforce foreign keys
  sqlDb.run('PRAGMA foreign_keys = ON;');

  // Create tables
  sqlDb.run(`
    CREATE TABLE IF NOT EXISTS administrators (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      username TEXT UNIQUE NOT NULL,
      password_hash TEXT NOT NULL,
      created_at TEXT NOT NULL,
      updated_at TEXT NOT NULL
    );

    CREATE TABLE IF NOT EXISTS business_settings (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      business_name TEXT NOT NULL,
      owner_name TEXT NOT NULL,
      address TEXT NOT NULL,
      plus_code TEXT NOT NULL,
      phone TEXT NOT NULL,
      whatsapp TEXT NOT NULL DEFAULT '8766660414',
      email TEXT NOT NULL,
      opening_hours TEXT NOT NULL,
      description TEXT NOT NULL,
      updated_at TEXT NOT NULL
    );

    CREATE TABLE IF NOT EXISTS fuel_categories (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      name TEXT UNIQUE NOT NULL,
      price_per_litre REAL NOT NULL DEFAULT 0.00,
      effective_date TEXT NOT NULL,
      is_active INTEGER NOT NULL DEFAULT 1,
      display_order INTEGER NOT NULL DEFAULT 0,
      updated_at TEXT NOT NULL
    );

    CREATE TABLE IF NOT EXISTS customer_services (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      title TEXT NOT NULL,
      description TEXT NOT NULL,
      icon_name TEXT NOT NULL,
      is_active INTEGER NOT NULL DEFAULT 1,
      display_order INTEGER NOT NULL DEFAULT 0,
      created_at TEXT NOT NULL,
      updated_at TEXT NOT NULL
    );

    CREATE TABLE IF NOT EXISTS gallery_images (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      title TEXT NOT NULL,
      description TEXT NOT NULL,
      image_url TEXT NOT NULL,
      is_active INTEGER NOT NULL DEFAULT 1,
      display_order INTEGER NOT NULL DEFAULT 0,
      created_at TEXT NOT NULL
    );

    CREATE TABLE IF NOT EXISTS feedback_submissions (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      customer_name TEXT NOT NULL,
      rating INTEGER NOT NULL,
      message TEXT NOT NULL,
      status TEXT NOT NULL DEFAULT 'PENDING',
      submitted_at TEXT NOT NULL,
      reviewed_at TEXT
    );

    CREATE TABLE IF NOT EXISTS enquiries (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      reference_no TEXT UNIQUE NOT NULL,
      customer_name TEXT NOT NULL,
      mobile_number TEXT NOT NULL,
      email TEXT,
      category TEXT NOT NULL DEFAULT 'General Enquiry',
      organization TEXT,
      subject TEXT NOT NULL,
      message TEXT NOT NULL,
      status TEXT NOT NULL DEFAULT 'New',
      admin_notes TEXT,
      submitted_at TEXT NOT NULL,
      updated_at TEXT NOT NULL
    );

    CREATE TABLE IF NOT EXISTS audit_logs (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      action TEXT NOT NULL,
      details TEXT,
      ip_address TEXT,
      created_at TEXT NOT NULL
    );

    CREATE TABLE IF NOT EXISTS homepage_appearance (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      background_image TEXT NOT NULL,
      position TEXT NOT NULL DEFAULT 'center',
      display_mode TEXT NOT NULL DEFAULT 'cover',
      overlay_intensity REAL NOT NULL DEFAULT 0.45,
      hero_height INTEGER NOT NULL DEFAULT 640,
      updated_at TEXT NOT NULL
    );

    CREATE TABLE IF NOT EXISTS announcements (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      message TEXT NOT NULL,
      link_url TEXT,
      is_active INTEGER NOT NULL DEFAULT 1,
      display_order INTEGER NOT NULL DEFAULT 0,
      start_date TEXT,
      end_date TEXT,
      created_at TEXT NOT NULL,
      updated_at TEXT NOT NULL
    );

    CREATE TABLE IF NOT EXISTS branding_settings (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      logo_url TEXT NOT NULL DEFAULT '/assets/hp-logo.png',
      logo_height INTEGER NOT NULL DEFAULT 56,
      brand_name TEXT NOT NULL DEFAULT 'RAJ PETROLEUM',
      tagline TEXT NOT NULL DEFAULT 'Hindustan Petroleum Retail Outlet',
      updated_at TEXT NOT NULL
    );

    CREATE TABLE IF NOT EXISTS hp_pay_section (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      title TEXT NOT NULL DEFAULT 'HP Pay App',
      heading TEXT NOT NULL DEFAULT 'Discover HP Pay',
      description TEXT NOT NULL,
      app_icon_url TEXT NOT NULL DEFAULT '/assets/hp-pay-logo.png',
      play_store_url TEXT NOT NULL DEFAULT 'https://play.google.com/store/apps/details?id=com.drivetrackplusrefuel',
      learn_more_url TEXT NOT NULL DEFAULT 'https://www.hindustanpetroleum.com/pages/mobile-app',
      is_visible INTEGER NOT NULL DEFAULT 1,
      is_deleted INTEGER NOT NULL DEFAULT 0,
      display_order INTEGER NOT NULL DEFAULT 6,
      features_json TEXT NOT NULL,
      created_at TEXT NOT NULL,
      updated_at TEXT NOT NULL
    );

    CREATE INDEX IF NOT EXISTS idx_fuel_active ON fuel_categories(is_active);
    CREATE INDEX IF NOT EXISTS idx_feedback_status ON feedback_submissions(status);
    CREATE INDEX IF NOT EXISTS idx_gallery_active ON gallery_images(is_active);
    CREATE INDEX IF NOT EXISTS idx_announcements_active ON announcements(is_active);
  `);

  // Column migrations if DB already existed from previous version
  try {
    sqlDb.run('ALTER TABLE customer_services ADD COLUMN icon_image_url TEXT');
  } catch (_) {}
  try {
    sqlDb.run('UPDATE customer_services SET is_active = 1 WHERE is_active IS NULL');
  } catch (_) {}
  try {
    sqlDb.run('UPDATE gallery_images SET is_active = 1 WHERE is_active IS NULL');
  } catch (_) {}
  try {
    sqlDb.run("ALTER TABLE business_settings ADD COLUMN whatsapp TEXT DEFAULT '8766660414'");
  } catch (_) {}
  try {
    sqlDb.run('ALTER TABLE enquiries ADD COLUMN reference_no TEXT');
  } catch (_) {}
  try {
    sqlDb.run("ALTER TABLE enquiries ADD COLUMN category TEXT DEFAULT 'General Enquiry'");
  } catch (_) {}
  try {
    sqlDb.run('ALTER TABLE enquiries ADD COLUMN organization TEXT');
  } catch (_) {}
  try {
    sqlDb.run('ALTER TABLE enquiries ADD COLUMN admin_notes TEXT');
  } catch (_) {}

  // Safe index creation for enquiries after migrations
  try {
    sqlDb.run('CREATE INDEX IF NOT EXISTS idx_enquiries_status ON enquiries(status)');
    sqlDb.run('CREATE INDEX IF NOT EXISTS idx_enquiries_ref ON enquiries(reference_no)');
  } catch (_) {}

  // Seed default administrator if not present
  const adminCount = queryOne<{ count: number }>('SELECT COUNT(*) AS count FROM administrators');
  if (!adminCount || adminCount.count === 0) {
    const saltRounds = 10;
    const initialHash = await bcrypt.hash('@Raj123', saltRounds);
    const now = new Date().toISOString();
    execute(
      'INSERT INTO administrators (username, password_hash, created_at, updated_at) VALUES (?, ?, ?, ?)',
      ['Raj123', initialHash, now, now]
    );
    console.log('[Database] Seeded initial administrator Raj123 with secure bcrypt hash');
  }

  // Seed business settings if not present
  const settingsCount = queryOne<{ count: number }>('SELECT COUNT(*) AS count FROM business_settings');
  if (!settingsCount || settingsCount.count === 0) {
    const now = new Date().toISOString();
    execute(
      `INSERT INTO business_settings (business_name, owner_name, address, plus_code, phone, whatsapp, email, opening_hours, description, updated_at)
       VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`,
      [
        'Raj Petroleum',
        'Sunita Patil',
        'Shop No. 1, Main Road, Nandre, Taluka Miraj, District Sangli, Maharashtra 416416, India.',
        'WGXW+GXR',
        '93721 47039',
        '8766660414',
        'rajpetroleum.nandre@gmail.com',
        '24 Hours / 7 Days a Week',
        'Raj Petroleum is an authorized Hindustan Petroleum (HPCL) retail outlet located on Main Road in Nandre, Taluka Miraj, Sangli. Dedicated to uncompromising fuel purity, precise automated dispensing, and prompt, courteous hospitality for daily commuters and highway travelers.',
        now,
      ]
    );
    console.log('[Database] Seeded verified business settings for Raj Petroleum');
  }


  // Seed initial fuel categories and prices if not present
  const fuelCount = queryOne<{ count: number }>('SELECT COUNT(*) AS count FROM fuel_categories');
  if (!fuelCount || fuelCount.count === 0) {
    const now = new Date().toISOString();
    const today = new Date().toISOString().split('T')[0];
    execute(
      'INSERT INTO fuel_categories (name, price_per_litre, effective_date, is_active, display_order, updated_at) VALUES (?, ?, ?, ?, ?, ?)',
      ['Petrol', 104.38, today, 1, 1, now]
    );
    execute(
      'INSERT INTO fuel_categories (name, price_per_litre, effective_date, is_active, display_order, updated_at) VALUES (?, ?, ?, ?, ?, ?)',
      ['Diesel', 90.82, today, 1, 2, now]
    );
    execute(
      'INSERT INTO fuel_categories (name, price_per_litre, effective_date, is_active, display_order, updated_at) VALUES (?, ?, ?, ?, ?, ?)',
      ['Power Petrol', 112.50, today, 1, 3, now]
    );
    console.log('[Database] Seeded initial fuel categories: Petrol, Diesel, Power Petrol');
  }

  // Seed confirmed customer services if not present
  const servicesCount = queryOne<{ count: number }>('SELECT COUNT(*) AS count FROM customer_services');
  if (!servicesCount || servicesCount.count === 0) {
    const now = new Date().toISOString();
    const services = [
      {
        title: 'High-Speed Fuel Dispensing',
        description: 'Automated multi-product electronic dispensers ensuring 100% accurate measure and rapid refueling for all 2-wheelers, 4-wheelers, and commercial vehicles.',
        icon: 'Fuel',
        order: 1,
      },
      {
        title: 'HP Power Petrol',
        description: 'High-octane premium petrol infused with specialized additives that reduce engine deposits, enhance acceleration, and improve fuel efficiency.',
        icon: 'Zap',
        order: 2,
      },
      {
        title: 'Digital Air & Nitrogen Filling',
        description: 'Complimentary automated digital tire pressure gauge and nitrogen station for longer tire lifespan and safer highway transit.',
        icon: 'Gauge',
        order: 3,
      },
      {
        title: 'Genuine HP Lubricants',
        description: 'Original factory-sealed Hindustan Petroleum engine oils, coolants, brake fluids, and greases suitable for commercial, agricultural, and passenger engines.',
        icon: 'Droplets',
        order: 4,
      },
      {
        title: 'Hygienic Restrooms',
        description: 'Clean, sanitized, and dedicated public washrooms available around the clock for visiting customers, families, and interstate drivers.',
        icon: 'Sparkles',
        order: 5,
      },
      {
        title: 'Pure Drinking Water Facility',
        description: 'Free, hygienic RO cold drinking water station always available for all commuters stopping at our forecourt.',
        icon: 'GlassWater',
        order: 6,
      },
      {
        title: 'Digital & Fleet Payments',
        description: 'Instant contactless payments via UPI, Bharat QR, Debit/Credit Cards, and HP DriveTrack Plus fleet card programs.',
        icon: 'CreditCard',
        order: 7,
      },
    ];

    for (const s of services) {
      execute(
        'INSERT INTO customer_services (title, description, icon_name, is_active, display_order, created_at, updated_at) VALUES (?, ?, ?, ?, ?, ?, ?)',
        [s.title, s.description, s.icon, 1, s.order, now, now]
      );
    }
    console.log('[Database] Seeded confirmed customer services');
  }

  // Seed initial gallery images using the verified pump photo and canopy assets
  const galleryCount = queryOne<{ count: number }>('SELECT COUNT(*) AS count FROM gallery_images');
  if (!galleryCount || galleryCount.count === 0) {
    const now = new Date().toISOString();
    execute(
      'INSERT INTO gallery_images (title, description, image_url, is_active, display_order, created_at) VALUES (?, ?, ?, ?, ?, ?)',
      [
        'Raj Petroleum Petrol Pump Forecourt & Lawn',
        'Wide scenic view of our modern HP retail station canopy, manicured lawn garden, and spacious highway access at Nandre, Sangli.',
        '/assets/raj-petroleum-hero.jpg',
        1,
        1,
        now,
      ]
    );
    execute(
      'INSERT INTO gallery_images (title, description, image_url, is_active, display_order, created_at) VALUES (?, ?, ?, ?, ?, ?)',
      [
        'Hindustan Petroleum Authorized Retail Station',
        'Official Hindustan Petroleum branding with modern high-speed dispensing nozzles and certified quality check standards.',
        '/assets/hp-logo.png',
        1,
        2,
        now,
      ]
    );
    console.log('[Database] Seeded initial gallery images');
  }

  // Seed sample approved customer review
  const feedbackCount = queryOne<{ count: number }>('SELECT COUNT(*) AS count FROM feedback_submissions');
  if (!feedbackCount || feedbackCount.count === 0) {
    const now = new Date().toISOString();
    execute(
      'INSERT INTO feedback_submissions (customer_name, rating, message, status, submitted_at, reviewed_at) VALUES (?, ?, ?, ?, ?, ?)',
      [
        'Mahesh Patil',
        5,
        'Excellent service and certified fuel purity. The staff is polite, fast, and the nitrogen air facility is very convenient on the Nandre road.',
        'APPROVED',
        now,
        now,
      ]
    );
    execute(
      'INSERT INTO feedback_submissions (customer_name, rating, message, status, submitted_at, reviewed_at) VALUES (?, ?, ?, ?, ?, ?)',
      [
        'Sachin Shinde',
        5,
        'Clean premises, polite attendants, and accurate digital dispensing. Best petrol pump in Miraj-Nandre area.',
        'APPROVED',
        now,
        now,
      ]
    );
    console.log('[Database] Seeded initial approved reviews');
  }

  // Column migrations if DB already existed
  try {
    execute('ALTER TABLE customer_services ADD COLUMN icon_image_url TEXT');
  } catch (_) {}
  try {
    execute('UPDATE customer_services SET is_active = 1 WHERE is_active IS NULL');
  } catch (_) {}
  try {
    execute('UPDATE gallery_images SET is_active = 1 WHERE is_active IS NULL');
  } catch (_) {}
  try {
    execute("ALTER TABLE business_settings ADD COLUMN whatsapp TEXT DEFAULT '8766660414'");
  } catch (_) {}
  try {
    execute('ALTER TABLE enquiries ADD COLUMN reference_no TEXT');
  } catch (_) {}
  try {
    execute("ALTER TABLE enquiries ADD COLUMN category TEXT DEFAULT 'General Enquiry'");
  } catch (_) {}
  try {
    execute('ALTER TABLE enquiries ADD COLUMN organization TEXT');
  } catch (_) {}
  try {
    execute('ALTER TABLE enquiries ADD COLUMN admin_notes TEXT');
  } catch (_) {}

  // Synchronize official verified contact numbers (Phone: 93721 47039, WhatsApp: 8766660414)
  try {
    execute(
      "UPDATE business_settings SET phone = '93721 47039', whatsapp = '8766660414' WHERE phone LIKE '%94220%' OR phone != '93721 47039' OR whatsapp IS NULL OR whatsapp = ''"
    );
  } catch (_) {}

  // Backfill unique reference numbers for any enquiries missing them
  try {
    const unreferenced = queryAll<{ id: number; submitted_at?: string }>(
      'SELECT id, submitted_at FROM enquiries WHERE reference_no IS NULL OR reference_no = ""'
    );
    for (const enq of unreferenced) {
      const year = enq.submitted_at ? new Date(enq.submitted_at).getFullYear() : new Date().getFullYear();
      const refNo = `RP-${year}-${String(10000 + enq.id).slice(1)}`;
      execute('UPDATE enquiries SET reference_no = ? WHERE id = ?', [refNo, enq.id]);
    }
    // Normalize status names to standard display values
    execute("UPDATE enquiries SET status = 'New' WHERE status = 'PENDING'");
    execute("UPDATE enquiries SET status = 'In Progress' WHERE status = 'IN_PROGRESS'");
    execute("UPDATE enquiries SET status = 'Resolved' WHERE status = 'RESOLVED'");
  } catch (_) {}


  // Seed homepage appearance if not present
  const appearanceCount = queryOne<{ count: number }>('SELECT COUNT(*) AS count FROM homepage_appearance');
  if (!appearanceCount || appearanceCount.count === 0) {
    const now = new Date().toISOString();
    execute(
      'INSERT INTO homepage_appearance (background_image, position, display_mode, overlay_intensity, hero_height, updated_at) VALUES (?, ?, ?, ?, ?, ?)',
      ['/assets/raj-petroleum-hero.jpg', 'center', 'cover', 0.45, 640, now]
    );
    console.log('[Database] Seeded default homepage appearance');
  }

  // Seed announcements if not present
  const announcementsCount = queryOne<{ count: number }>('SELECT COUNT(*) AS count FROM announcements');
  if (!announcementsCount || announcementsCount.count === 0) {
    const now = new Date().toISOString();
    execute(
      'INSERT INTO announcements (message, link_url, is_active, display_order, created_at, updated_at) VALUES (?, ?, ?, ?, ?, ?)',
      [
        '⚡ Welcome to Raj Petroleum — Certified HPCL Fuel, Free Digital Air Check & 24/7 Forecourt Service at Nandre!',
        '#services',
        1,
        1,
        now,
        now,
      ]
    );
    execute(
      'INSERT INTO announcements (message, link_url, is_active, display_order, created_at, updated_at) VALUES (?, ?, ?, ?, ?, ?)',
      [
        '🚗 HP Power Petrol & Genuine HP Lubricants Available. Ask Attendant for HP DriveTrack Plus Loyalty Benefits!',
        '#fuel-price',
        1,
        2,
        now,
        now,
      ]
    );
    console.log('[Database] Seeded default announcements');
  }

  // Seed branding settings if not present
  const brandingCount = queryOne<{ count: number }>('SELECT COUNT(*) AS count FROM branding_settings');
  if (!brandingCount || brandingCount.count === 0) {
    const now = new Date().toISOString();
    execute(
      'INSERT INTO branding_settings (logo_url, logo_height, brand_name, tagline, updated_at) VALUES (?, ?, ?, ?, ?)',
      ['/assets/hp-logo.png', 56, 'RAJ PETROLEUM', 'Hindustan Petroleum Retail Outlet', now]
    );
    console.log('[Database] Seeded default branding settings');
  }

  // Seed HP Pay section if not present
  const hpPayCount = queryOne<{ count: number }>('SELECT COUNT(*) AS count FROM hp_pay_section');
  if (!hpPayCount || hpPayCount.count === 0) {
    const now = new Date().toISOString();
    const defaultFeatures = [
      {
        id: 'feat_1',
        title: 'Contactless Fuel Payments',
        description: 'Pay quickly and securely for Petrol, Diesel, and HP Power Petrol via UPI, Credit/Debit cards, or HP Pay Wallet without handling cash.',
        icon: 'CreditCard',
      },
      {
        id: 'feat_2',
        title: 'Scan QR & Instant Paycode',
        description: 'Scan dynamic HPCL QR codes at our forecourt dispensers or generate a one-time Paycode for touchless refueling transactions.',
        icon: 'QrCode',
      },
      {
        id: 'feat_3',
        title: 'Integrated HP Pay Wallet & FASTag',
        description: 'Maintain a dedicated fuel wallet, recharge toll FASTag, and monitor all your commercial or private vehicle fueling expenses in real time.',
        icon: 'Wallet',
      },
      {
        id: 'feat_4',
        title: 'Earn & Redeem Reward Points',
        description: 'Accumulate loyalty points on every fuel purchase and redeem them directly for free fuel at authorized Hindustan Petroleum outlets.',
        icon: 'Gift',
      },
      {
        id: 'feat_5',
        title: 'HP Gas LPG Cylinder Booking',
        description: 'Book and pay for domestic or commercial HP Gas LPG refills conveniently from your smartphone with digital receipts.',
        icon: 'Flame',
      },
      {
        id: 'feat_6',
        title: 'Forecourt & Outlet Locator',
        description: 'Locate authorized HPCL retail outlets across national and state highways with live services, air stations, and facility details.',
        icon: 'MapPin',
      },
    ];

    execute(
      `INSERT INTO hp_pay_section (title, heading, description, app_icon_url, play_store_url, learn_more_url, is_visible, is_deleted, display_order, features_json, created_at, updated_at)
       VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`,
      [
        'HP Pay App',
        'Discover HP Pay',
        'HP Pay is a digital payment and convenience application from Hindustan Petroleum Corporation Limited (HPCL). Explore the app\'s supported fuel payment options, digital payment features, rewards, and other available services.',
        '/assets/hp-pay-logo.png',
        'https://play.google.com/store/apps/details?id=com.drivetrackplusrefuel',
        'https://www.hindustanpetroleum.com/pages/mobile-app',
        1,
        0,
        6,
        JSON.stringify(defaultFeatures),
        now,
        now,
      ]
    );
    console.log('[Database] Seeded official HP Pay App section');
  }

  saveDbToDisk();
}
