export interface BusinessSettings {
  business_name: string;
  owner_name: string;
  address: string;
  plus_code: string;
  phone: string;
  whatsapp?: string;
  email: string;
  opening_hours: string;
  description: string;
}

export interface HomepageAppearance {
  id?: number;
  background_image: string;
  position: 'center' | 'top' | 'bottom';
  display_mode: 'cover' | 'contain';
  overlay_intensity: number;
  hero_height: number;
  updated_at?: string;
}

export interface FuelCategory {
  id: number;
  name: string;
  price_per_litre: number;
  effective_date: string;
  is_active: number | boolean;
  display_order: number;
  updated_at: string;
}

export interface CustomerService {
  id: number;
  title: string;
  description: string;
  icon_name: string;
  icon_image_url?: string | null;
  is_active: number | boolean;
  display_order: number;
  created_at?: string;
  updated_at?: string;
}

export interface Announcement {
  id: number;
  message: string;
  link_url?: string | null;
  is_active: number | boolean;
  display_order: number;
  start_date?: string | null;
  end_date?: string | null;
  created_at?: string;
  updated_at?: string;
}

export interface BrandingSettings {
  id?: number;
  logo_url: string;
  logo_height: number;
  brand_name: string;
  tagline: string;
  updated_at?: string;
}

export interface GalleryImage {
  id: number;
  title: string;
  description: string;
  image_url: string;
  is_active: number | boolean;
  display_order: number;
  created_at?: string;
}

export interface FeedbackSubmission {
  id: number;
  customer_name: string;
  rating: number;
  message: string;
  status: 'PENDING' | 'APPROVED' | 'REJECTED';
  submitted_at: string;
  reviewed_at?: string;
}

export interface CustomerReview {
  id: number;
  customer_name: string;
  rating: number;
  message: string;
  submitted_at: string;
}

export type EnquiryStatus = 'New' | 'In Progress' | 'Responded' | 'Resolved';

export interface CustomerEnquiry {
  id: number;
  reference_no: string;
  customer_name: string;
  mobile_number: string;
  email?: string | null;
  category: string;
  organization?: string | null;
  subject: string;
  message: string;
  status: EnquiryStatus;
  admin_notes?: string | null;
  submitted_at: string;
  updated_at: string;
}

export interface DashboardStats {
  fuelCategories: number;
  customerServices: number;
  galleryImages: number;
  pendingFeedback: number;
  approvedReviews: number;
  totalEnquiries: number;
  pendingEnquiries: number;
  resolvedEnquiries: number;
}

export interface HpPayFeature {
  id: string;
  title: string;
  description: string;
  icon: string;
}

export interface HpPaySectionData {
  id?: number;
  title: string;
  heading: string;
  description: string;
  app_icon_url: string;
  play_store_url: string;
  learn_more_url: string;
  is_visible: number | boolean;
  is_deleted: number | boolean;
  display_order: number;
  features: HpPayFeature[];
  created_at?: string;
  updated_at?: string;
}


