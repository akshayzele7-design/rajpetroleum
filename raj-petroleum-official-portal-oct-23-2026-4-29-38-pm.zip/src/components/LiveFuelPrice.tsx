import React from 'react';
import { Fuel, Calendar, Clock, RefreshCw, Zap, ShieldCheck, AlertCircle } from 'lucide-react';
import { FuelCategory } from '../types';

interface LiveFuelPriceProps {
  fuelPrices: FuelCategory[];
  isLoading: boolean;
  error?: string | null;
  onRefresh?: () => void;
}

export const LiveFuelPrice: React.FC<LiveFuelPriceProps> = ({
  fuelPrices,
  isLoading,
  error,
  onRefresh,
}) => {
  // Format readable timestamp
  const formatDateTime = (dateStr?: string) => {
    if (!dateStr) return 'Recently';
    try {
      const d = new Date(dateStr);
      if (isNaN(d.getTime())) return dateStr;
      return d.toLocaleDateString('en-IN', {
        day: 'numeric',
        month: 'short',
        year: 'numeric',
        hour: '2-digit',
        minute: '2-digit',
      });
    } catch {
      return dateStr;
    }
  };

  const formatDateOnly = (dateStr?: string) => {
    if (!dateStr) return '';
    try {
      const d = new Date(dateStr);
      if (isNaN(d.getTime())) return dateStr;
      return d.toLocaleDateString('en-IN', {
        day: 'numeric',
        month: 'short',
        year: 'numeric',
      });
    } catch {
      return dateStr;
    }
  };

  // Safe active check (all records returned by /api/public/fuel-prices are active)
  const activePrices = (fuelPrices || []).filter(
    (f) =>
      f.is_active === undefined ||
      f.is_active === null ||
      f.is_active === 1 ||
      f.is_active === true ||
      (f.is_active as any) === '1'
  );

  const latestUpdated = activePrices.reduce((latest, current) => {
    if (!latest) return current.updated_at || '';
    return new Date(current.updated_at) > new Date(latest) ? current.updated_at : latest;
  }, '');

  return (
    <section id="fuel-price" className="py-14 bg-white border-b border-slate-200">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Section Header */}
        <div className="flex flex-col md:flex-row md:items-end justify-between mb-8 pb-4 border-b border-slate-200 gap-4">
          <div>
            <div className="flex items-center gap-2 text-xs font-black text-[#0756A5] uppercase tracking-wider mb-1.5">
              <span className="w-2.5 h-2.5 rounded-full bg-[#0756A5]"></span>
              <span>Daily Official Fuel Tariff</span>
            </div>
            <h2 className="text-2xl sm:text-3xl lg:text-4xl font-black text-[#123B68] tracking-tight">
              Live Fuel Prices
            </h2>
            <p className="text-sm text-slate-600 mt-1">
              Transparent, government-regulated Hindustan Petroleum rates at Raj Petroleum, Nandre, Sangli.
            </p>
          </div>

          <div className="flex items-center gap-3 text-xs text-slate-500 shrink-0">
            {latestUpdated && (
              <span className="flex items-center gap-1.5 bg-[#F3F6F9] border border-slate-200 px-3.5 py-2 rounded-lg text-slate-700 font-bold">
                <Clock className="w-4 h-4 text-[#0756A5]" />
                <span>Last updated: {formatDateTime(latestUpdated)}</span>
              </span>
            )}

            {onRefresh && (
              <button
                onClick={onRefresh}
                disabled={isLoading}
                title="Refresh Prices"
                className="inline-flex items-center gap-1.5 px-3 py-2 text-xs font-bold bg-[#F3F6F9] hover:bg-slate-200 text-[#0756A5] border border-slate-200 rounded-lg transition-colors cursor-pointer"
              >
                <RefreshCw className={`w-3.5 h-3.5 ${isLoading ? 'animate-spin' : ''}`} />
                <span>{isLoading ? 'Updating...' : 'Refresh'}</span>
              </button>
            )}
          </div>
        </div>

        {/* Error message fallback if API fails */}
        {error && (
          <div className="mb-6 p-4 bg-rose-50 border border-rose-200 rounded-xl flex items-center justify-between text-rose-800 text-xs font-semibold">
            <div className="flex items-center gap-2">
              <AlertCircle className="w-5 h-5 text-[#D62828] shrink-0" />
              <span>{error}</span>
            </div>
            {onRefresh && (
              <button
                onClick={onRefresh}
                className="px-3 py-1 bg-[#D62828] text-white rounded text-xs font-bold hover:bg-[#b81d1d]"
              >
                Try Again
              </button>
            )}
          </div>
        )}

        {/* Pricing Cards Grid */}
        {isLoading && activePrices.length === 0 ? (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 lg:gap-8">
            {[1, 2, 3].map((n) => (
              <div key={n} className="h-64 bg-[#F3F6F9] rounded-2xl animate-pulse border border-slate-200"></div>
            ))}
          </div>
        ) : activePrices.length === 0 ? (
          <div className="bg-[#FFFDF7] border border-amber-200 text-amber-900 p-8 rounded-2xl text-center max-w-lg mx-auto shadow-xs">
            <Fuel className="w-12 h-12 text-amber-600 mx-auto mb-3" />
            <h3 className="text-lg font-black text-amber-900">Fuel prices will be updated soon.</h3>
            <p className="text-xs text-amber-800 mt-1 leading-relaxed">
              The station office is currently calibrating today's dispatch rates. Please contact the pump directly for immediate rates.
            </p>
            {onRefresh && (
              <button
                onClick={onRefresh}
                className="mt-4 inline-flex items-center gap-1.5 px-4 py-2 bg-[#0756A5] text-white rounded-lg text-xs font-bold hover:bg-[#123B68] transition-colors cursor-pointer"
              >
                <RefreshCw className="w-3.5 h-3.5" />
                <span>Check for Updates</span>
              </button>
            )}
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 lg:gap-8">
            {activePrices.map((fuel) => {
              const nameLower = fuel.name.toLowerCase();
              const isPower = nameLower.includes('power');
              const isDiesel = nameLower.includes('diesel');

              return (
                <div
                  key={fuel.id}
                  className="relative bg-gradient-to-b from-[#123B68] to-[#0756A5] text-white rounded-2xl p-6 sm:p-7 transition-all duration-200 border border-blue-900/60 ring-1 ring-blue-400/30 shadow-lg hover:shadow-xl flex flex-col justify-between overflow-hidden group"
                >
                  {/* Card Header: Icon, Subtitle, Fuel Name & Category Tag */}
                  <div>
                    <div className="flex items-start justify-between gap-3 mb-4">
                      <div className="flex items-center gap-3">
                        <div className="w-12 h-12 rounded-xl flex items-center justify-center shrink-0 bg-white/15 text-white border border-white/20 shadow-xs backdrop-blur-xs">
                          {isPower ? (
                            <Zap className="w-6 h-6 text-yellow-300" />
                          ) : (
                            <Fuel className="w-6 h-6 text-white" />
                          )}
                        </div>
                        <div>
                          <span className="text-[11px] font-bold uppercase tracking-wider text-blue-200 block">
                            Hindustan Petroleum
                          </span>
                          <h3 className="text-xl sm:text-2xl font-black tracking-tight uppercase text-white drop-shadow-xs">
                            {fuel.name}
                          </h3>
                        </div>
                      </div>

                      {/* Right Tag: Yellow Highlight for Power Petrol, Clean subtle badges for others */}
                      {isPower ? (
                        <span className="text-[10px] font-black uppercase tracking-wider bg-yellow-400 text-slate-900 px-2.5 py-1 rounded-md shadow-xs shrink-0">
                          High Octane
                        </span>
                      ) : isDiesel ? (
                        <span className="text-[10px] font-bold uppercase tracking-wider bg-white/15 text-blue-100 border border-white/20 px-2.5 py-1 rounded-md shrink-0">
                          High Speed
                        </span>
                      ) : (
                        <span className="text-[10px] font-bold uppercase tracking-wider bg-white/15 text-blue-100 border border-white/20 px-2.5 py-1 rounded-md shrink-0">
                          Motor Spirit
                        </span>
                      )}
                    </div>

                    {/* Prominent Price Box in White */}
                    <div className="my-5 py-4 px-4 sm:px-5 bg-white/10 rounded-xl border border-white/15 backdrop-blur-xs">
                      <div className="flex items-center justify-between text-xs font-bold uppercase tracking-wider text-blue-200 mb-1.5">
                        <span>Price per litre</span>
                        <span className="text-[10px] font-semibold text-blue-300/80">Daily Tariff</span>
                      </div>
                      <div className="flex items-baseline gap-1.5">
                        <span className="text-2xl sm:text-3xl font-black text-white drop-shadow-xs">
                          ₹
                        </span>
                        <span className="text-4xl sm:text-5xl font-black tabular-nums tracking-tight text-white drop-shadow-xs">
                          {Number(fuel.price_per_litre).toFixed(2)}
                        </span>
                        <span className="text-xs font-bold uppercase text-blue-200 ml-1">
                          / LITRE
                        </span>
                      </div>
                    </div>
                  </div>

                  {/* Footer metadata: Effective date & Certified guarantee */}
                  <div className="pt-2 flex items-center justify-between text-xs text-blue-100 border-t border-white/15 gap-2">
                    <span className="flex items-center gap-1.5 font-medium truncate">
                      <Calendar className="w-3.5 h-3.5 text-blue-200 shrink-0" />
                      <span>Effective: {formatDateOnly(fuel.effective_date)}</span>
                    </span>
                    <span className="inline-flex items-center gap-1 font-bold text-emerald-300 bg-white/10 border border-white/15 px-2 py-0.5 rounded shrink-0">
                      <ShieldCheck className="w-3.5 h-3.5 text-emerald-300 shrink-0" />
                      <span>100% Certified</span>
                    </span>
                  </div>
                </div>
              );
            })}
          </div>
        )}

        <div className="mt-8 pt-4 border-t border-slate-100 flex flex-col sm:flex-row items-center justify-between text-xs text-slate-500 gap-2">
          <span>* Rates are inclusive of Central Excise and Maharashtra State VAT. Calibrated daily at 06:00 AM IST.</span>
          <span className="font-semibold text-slate-600">Density & Quantity verification facility available on demand.</span>
        </div>
      </div>
    </section>
  );
};
