import React, { useState, useEffect } from 'react';
import { Phone, Menu, X, Clock, MapPin, ShieldCheck } from 'lucide-react';
import { BusinessSettings, BrandingSettings } from '../types';

interface HeaderProps {
  settings: BusinessSettings | null;
  branding?: BrandingSettings | null;
  activeSection: string;
  showHpPay?: boolean;
}

const allNavItems = [
  { id: 'home', label: 'HOME', href: '#home' },
  { id: 'fuel-price', label: 'FUEL PRICE', href: '#fuel-price' },
  { id: 'about', label: 'ABOUT', href: '#about' },
  { id: 'services', label: 'SERVICES', href: '#services' },
  { id: 'gallery', label: 'GALLERY', href: '#gallery' },
  { id: 'hp-pay', label: 'HP PAY', href: '#hp-pay' },
  { id: 'feedback', label: 'FEEDBACK', href: '#feedback' },
  { id: 'reviews', label: 'REVIEWS', href: '#reviews' },
  { id: 'support', label: 'SUPPORT', href: '#support' },
  { id: 'location', label: 'LOCATION', href: '#location' },
  { id: 'contact', label: 'CONTACT', href: '#contact' },
];

export const Header: React.FC<HeaderProps> = ({ settings, branding, activeSection, showHpPay = true }) => {
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const navItems = showHpPay === false ? allNavItems.filter((i) => i.id !== 'hp-pay') : allNavItems;

  // Close mobile menu on resize to desktop
  useEffect(() => {
    const handleResize = () => {
      if (window.innerWidth >= 768) {
        setMobileMenuOpen(false);
      }
    };
    window.addEventListener('resize', handleResize);
    return () => window.removeEventListener('resize', handleResize);
  }, []);

  const phone = settings?.phone || '93721 47039';
  const logoUrl = branding?.logo_url || '/assets/hp-logo.png';
  const logoHeight = branding?.logo_height || 56;
  const brandName = branding?.brand_name || 'RAJ PETROLEUM';
  const brandTagline = branding?.tagline || 'Hindustan Petroleum Retail Outlet';


  return (
    <header className="sticky top-0 z-50 w-full bg-white shadow-md">
      {/* 1. Top Announcement Strip */}
      <div className="bg-[#123B68] text-white text-[11px] sm:text-xs px-4 sm:px-8 py-1.5 flex justify-between items-center tracking-wide border-b border-blue-900">
        <div className="flex items-center gap-4">
          <span className="flex items-center gap-1.5 font-medium text-blue-100">
            <Clock className="w-3.5 h-3.5 text-blue-300" />
            <span>Open 24 Hours / 7 Days</span>
          </span>
          <span className="hidden sm:inline-block text-blue-300/40">|</span>
          <span className="hidden sm:flex items-center gap-1.5 text-blue-100">
            <MapPin className="w-3.5 h-3.5 text-[#D62828]" />
            <span>Nandre, Taluka Miraj, Sangli 416416</span>
          </span>
        </div>

        <div className="flex items-center gap-3">
          <span className="hidden md:inline-flex items-center gap-1 text-blue-200">
            <ShieldCheck className="w-3.5 h-3.5 text-emerald-400" />
            <span>Authorized HPCL Dealership</span>
          </span>
          <span className="hidden md:inline-block text-blue-300/40">·</span>
          <a
            href={`tel:${phone.replace(/\s+/g, '')}`}
            className="flex items-center gap-1.5 font-bold text-white hover:text-blue-200 transition-colors"
          >
            <Phone className="w-3.5 h-3.5 text-[#D62828]" />
            <span className="tabular-nums">{phone}</span>
          </a>
        </div>
      </div>

      {/* 2. Main Brand Header Row */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between min-h-[5rem] py-2 gap-4">
          {/* Left: HP Brand Logo + Raj Petroleum */}
          <a href="#home" className="flex items-center gap-3 sm:gap-4 group shrink-0">
            <div className="relative flex items-center justify-center shrink-0">
              <img
                src={logoUrl}
                alt={`${brandName} Logo`}
                style={{ height: `${logoHeight}px`, width: 'auto', maxHeight: '72px' }}
                className="object-contain transition-transform group-hover:scale-105"
                onError={(e) => {
                  // Fallback to default HP logo if custom logo fails
                  const img = e.currentTarget as HTMLImageElement;
                  if (img.src !== window.location.origin + '/assets/hp-logo.png') {
                    img.src = '/assets/hp-logo.png';
                  }
                }}
              />
            </div>
            <div className="flex flex-col">
              <span className="text-2xl sm:text-3xl font-black tracking-tight text-[#0756A5] leading-none group-hover:text-[#123B68] transition-colors">
                {brandName}
              </span>
              <span className="text-xs font-bold text-slate-500 uppercase tracking-wider mt-1">
                {brandTagline}
              </span>
            </div>
          </a>

          {/* Right Header Action: Call Now button & status */}
          <div className="flex items-center gap-3">
            <div className="hidden lg:flex flex-col text-right mr-2">
              <span className="text-[11px] font-bold text-slate-400 uppercase tracking-wider">Helpline & Dispatch</span>
              <a
                href={`tel:${phone.replace(/\s+/g, '')}`}
                className="text-sm font-extrabold text-[#123B68] hover:text-[#0756A5] tabular-nums"
              >
                {phone}
              </a>
            </div>

            <a
              href={`tel:${phone.replace(/\s+/g, '')}`}
              className="hidden sm:inline-flex items-center gap-2 bg-[#D62828] hover:bg-[#b81d1d] text-white text-xs font-extrabold uppercase tracking-wider px-4 py-2.5 rounded-lg shadow-sm hover:shadow transition-all transform active:scale-95"
            >
              <Phone className="w-3.5 h-3.5" />
              <span>Call Now</span>
            </a>

            {/* Mobile Hamburger Toggle (strictly on small mobile screens: md:hidden) */}
            <div className="flex md:hidden items-center ml-1">
              <button
                onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
                className="p-2 text-slate-700 hover:text-[#0756A5] hover:bg-slate-100 rounded-lg focus:outline-hidden"
                aria-label={mobileMenuOpen ? 'Close menu' : 'Open navigation menu'}
              >
                {mobileMenuOpen ? <X className="w-6 h-6 text-[#D62828]" /> : <Menu className="w-6 h-6" />}
              </button>
            </div>
          </div>
        </div>
      </div>

      {/* 3. Clearly Visible Horizontal Navigation Bar BELOW Main Header (Desktop & Tablet) */}
      <div className="hidden md:block w-full bg-[#0756A5] border-t border-b border-[#123B68] shadow-inner">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <nav className="flex items-center justify-between flex-nowrap whitespace-nowrap overflow-x-auto scrollbar-none py-0">
            {navItems.map((item) => {
              const isActive = activeSection === item.id || (item.id === 'support' && activeSection === 'enquiry');
              return (
                <a
                  key={item.id}
                  href={item.href}
                  className={`text-[12px] lg:text-[13px] font-bold tracking-wider px-3 lg:px-3.5 py-3 transition-all duration-150 relative whitespace-nowrap shrink-0 ${
                    isActive
                      ? 'text-white bg-[#123B68] font-black'
                      : 'text-blue-100 hover:text-white hover:bg-white/10'
                  }`}
                >
                  <span>{item.label}</span>
                  {/* Subtle red accent highlight for active item */}
                  {isActive && (
                    <span className="absolute bottom-0 left-0 right-0 h-1 bg-[#D62828]"></span>
                  )}
                </a>
              );
            })}
          </nav>
        </div>
      </div>

      {/* 4. Responsive Mobile Collapsible Menu */}
      {mobileMenuOpen && (
        <div className="md:hidden bg-[#123B68] text-white border-t border-blue-900 px-4 pt-3 pb-6 shadow-xl animate-in fade-in duration-150">
          <div className="grid grid-cols-2 gap-1 py-1">
            {navItems.map((item) => {
              const isActive = activeSection === item.id || (item.id === 'support' && activeSection === 'enquiry');
              return (
                <a
                  key={item.id}
                  href={item.href}
                  onClick={() => setMobileMenuOpen(false)}
                  className={`px-3 py-2.5 text-xs font-bold rounded transition-colors ${
                    isActive
                      ? 'bg-[#0756A5] text-white border-l-4 border-[#D62828]'
                      : 'text-blue-100 hover:bg-white/10'
                  }`}
                >
                  {item.label}
                </a>
              );
            })}
          </div>


          <div className="pt-4 mt-3 border-t border-blue-800 flex flex-col gap-2">
            <a
              href={`tel:${phone.replace(/\s+/g, '')}`}
              className="w-full text-center inline-flex items-center justify-center gap-2 bg-[#D62828] text-white text-xs font-bold py-3 rounded-lg shadow-sm"
            >
              <Phone className="w-4 h-4" />
              <span>Call Now: {phone}</span>
            </a>
          </div>
        </div>
      )}
    </header>
  );
};
