import React, { useState } from 'react';
import { Star, MessageSquare, Send, CheckCircle2, AlertCircle } from 'lucide-react';
import { submitPublicFeedback } from '../api';

export const FeedbackForm: React.FC = () => {
  const [customerName, setCustomerName] = useState('');
  const [rating, setRating] = useState(5);
  const [hoverRating, setHoverRating] = useState(0);
  const [message, setMessage] = useState('');
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [successMsg, setSuccessMsg] = useState<string | null>(null);
  const [errorMsg, setErrorMsg] = useState<string | null>(null);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!customerName.trim() || !message.trim()) {
      setErrorMsg('Please provide your name and your feedback message.');
      return;
    }

    setIsSubmitting(true);
    setErrorMsg(null);
    setSuccessMsg(null);

    try {
      const res = await submitPublicFeedback({
        customer_name: customerName,
        rating,
        message,
      });
      setSuccessMsg(res.message);
      setCustomerName('');
      setMessage('');
      setRating(5);
    } catch (err: any) {
      setErrorMsg(err.message || 'Failed to submit feedback. Please try again.');
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <section id="feedback" className="py-16 bg-white border-b border-slate-200">
      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center max-w-2xl mx-auto mb-10">
          <div className="inline-flex items-center gap-1.5 text-xs font-bold text-[#0756A5] uppercase tracking-wider mb-2">
            <MessageSquare className="w-4 h-4 text-[#0756A5]" />
            <span>Customer Experience Matters</span>
          </div>
          <h2 className="text-3xl sm:text-4xl font-extrabold text-[#123B68] tracking-tight">
            Share Your Feedback
          </h2>
          <div className="w-16 h-1 bg-[#0756A5] mx-auto mt-3 mb-4 rounded-full"></div>
          <p className="text-sm text-slate-600">
            Tell us about your experience at Raj Petroleum. Your feedback helps us continuously improve fuel dispensing and customer amenities.
          </p>
        </div>

        <div className="bg-[#FFFDF7] p-6 sm:p-8 rounded-2xl border border-slate-200 shadow-sm">
          {successMsg && (
            <div className="mb-6 p-4 bg-emerald-50 border border-emerald-200 text-emerald-800 rounded-lg flex items-start gap-3">
              <CheckCircle2 className="w-5 h-5 text-emerald-600 shrink-0 mt-0.5" />
              <div>
                <h4 className="text-sm font-bold">Feedback Received!</h4>
                <p className="text-xs mt-0.5">{successMsg}</p>
              </div>
            </div>
          )}

          {errorMsg && (
            <div className="mb-6 p-4 bg-rose-50 border border-rose-200 text-rose-800 rounded-lg flex items-start gap-3">
              <AlertCircle className="w-5 h-5 text-rose-600 shrink-0 mt-0.5" />
              <p className="text-xs font-medium">{errorMsg}</p>
            </div>
          )}

          <form onSubmit={handleSubmit} className="space-y-5">
            <div>
              <label htmlFor="feedback-name" className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-1.5">
                Your Full Name <span className="text-[#D62828]">*</span>
              </label>
              <input
                id="feedback-name"
                type="text"
                required
                maxLength={100}
                placeholder="e.g. Anand Kulkarni"
                value={customerName}
                onChange={(e) => setCustomerName(e.target.value)}
                className="w-full px-4 py-2.5 text-sm bg-white border border-slate-300 rounded-lg focus:outline-hidden focus:border-[#0756A5] focus:ring-1 focus:ring-[#0756A5]"
              />
            </div>

            <div>
              <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-1.5">
                Rating <span className="text-[#D62828]">*</span>
              </label>
              <div className="flex items-center gap-2">
                {[1, 2, 3, 4, 5].map((star) => {
                  const active = (hoverRating || rating) >= star;
                  return (
                    <button
                      key={star}
                      type="button"
                      onClick={() => setRating(star)}
                      onMouseEnter={() => setHoverRating(star)}
                      onMouseLeave={() => setHoverRating(0)}
                      className="p-1 focus:outline-hidden"
                      aria-label={`Rate ${star} stars`}
                    >
                      <Star
                        className={`w-7 h-7 transition-colors ${
                          active
                            ? 'fill-amber-400 text-amber-400'
                            : 'text-slate-300 hover:text-amber-200'
                        }`}
                      />
                    </button>
                  );
                })}
                <span className="text-xs font-semibold text-slate-600 ml-2">
                  {rating} of 5 Stars
                </span>
              </div>
            </div>

            <div>
              <label htmlFor="feedback-message" className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-1.5">
                Your Review / Experience <span className="text-[#D62828]">*</span>
              </label>
              <textarea
                id="feedback-message"
                rows={4}
                required
                maxLength={1500}
                placeholder="Share your experience regarding fuel quality, staff courtesy, speed of service, or station cleanliness..."
                value={message}
                onChange={(e) => setMessage(e.target.value)}
                className="w-full px-4 py-2.5 text-sm bg-white border border-slate-300 rounded-lg focus:outline-hidden focus:border-[#0756A5] focus:ring-1 focus:ring-[#0756A5]"
              ></textarea>
            </div>

            <div className="pt-2">
              <button
                type="submit"
                disabled={isSubmitting}
                className="inline-flex items-center justify-center gap-2 px-6 py-3 bg-[#0756A5] hover:bg-[#123B68] text-white text-xs font-bold uppercase tracking-wider rounded-lg shadow-sm hover:shadow transition-all disabled:opacity-50"
              >
                <Send className="w-4 h-4" />
                <span>{isSubmitting ? 'Submitting...' : 'Submit Feedback'}</span>
              </button>
            </div>
          </form>
        </div>
      </div>
    </section>
  );
};
