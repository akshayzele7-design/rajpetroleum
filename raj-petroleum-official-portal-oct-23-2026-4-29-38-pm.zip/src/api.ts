import {
  BusinessSettings,
  HomepageAppearance,
  FuelCategory,
  CustomerService,
  GalleryImage,
  CustomerReview,
  FeedbackSubmission,
  CustomerEnquiry,
  DashboardStats,
  Announcement,
  BrandingSettings,
  HpPaySectionData,
} from './types';

const TOKEN_KEY = 'raj_petroleum_admin_token';

export const authStorage = {
  getToken(): string | null {
    return localStorage.getItem(TOKEN_KEY) || sessionStorage.getItem(TOKEN_KEY);
  },
  setToken(token: string, remember: boolean = true) {
    if (remember) {
      localStorage.setItem(TOKEN_KEY, token);
    } else {
      sessionStorage.setItem(TOKEN_KEY, token);
    }
  },
  clearToken() {
    localStorage.removeItem(TOKEN_KEY);
    sessionStorage.removeItem(TOKEN_KEY);
  },
  isAuthenticated(): boolean {
    return !!this.getToken();
  },
};

function authHeaders(): HeadersInit {
  const token = authStorage.getToken();
  return {
    'Content-Type': 'application/json',
    ...(token ? { Authorization: `Bearer ${token}` } : {}),
  };
}

// ---------------------------------------------------------------------------
// PUBLIC API CALLS
// ---------------------------------------------------------------------------

export async function fetchPublicSettings(): Promise<BusinessSettings> {
  const res = await fetch('/api/public/settings');
  if (!res.ok) throw new Error('Failed to load business settings');
  return res.json();
}

export async function fetchPublicAppearance(): Promise<HomepageAppearance> {
  const res = await fetch('/api/public/appearance');
  if (!res.ok) throw new Error('Failed to load homepage appearance');
  return res.json();
}

export async function fetchPublicFuelPrices(): Promise<FuelCategory[]> {
  const res = await fetch('/api/public/fuel-prices');
  if (!res.ok) throw new Error('Failed to load fuel prices');
  return res.json();
}

export async function fetchPublicServices(): Promise<CustomerService[]> {
  const res = await fetch('/api/public/services');
  if (!res.ok) throw new Error('Failed to load customer services');
  return res.json();
}

export async function fetchPublicGallery(): Promise<GalleryImage[]> {
  const res = await fetch('/api/public/gallery');
  if (!res.ok) throw new Error('Failed to load gallery images');
  return res.json();
}

export async function fetchPublicAnnouncements(): Promise<Announcement[]> {
  const res = await fetch('/api/public/announcements');
  if (!res.ok) throw new Error('Failed to load announcements');
  return res.json();
}

export async function fetchPublicBranding(): Promise<BrandingSettings> {
  const res = await fetch('/api/public/branding');
  if (!res.ok) throw new Error('Failed to load branding settings');
  return res.json();
}

export async function fetchPublicReviews(): Promise<CustomerReview[]> {
  const res = await fetch('/api/public/reviews');
  if (!res.ok) throw new Error('Failed to load reviews');
  return res.json();
}

export async function submitPublicFeedback(data: {
  customer_name: string;
  rating: number;
  message: string;
}): Promise<{ success: boolean; message: string }> {
  const res = await fetch('/api/public/feedback', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(data),
  });
  const json = await res.json();
  if (!res.ok) throw new Error(json.error || 'Failed to submit feedback');
  return json;
}

export async function submitPublicEnquiry(data: {
  customer_name: string;
  mobile_number: string;
  email?: string;
  category: string;
  organization?: string;
  subject: string;
  message: string;
}): Promise<{ success: boolean; message: string; reference_no: string }> {
  const res = await fetch('/api/public/enquiry', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(data),
  });
  const json = await res.json();
  if (!res.ok) throw new Error(json.error || 'Failed to submit enquiry');
  return json;
}


// ---------------------------------------------------------------------------
// ADMIN API CALLS
// ---------------------------------------------------------------------------

export async function adminLogin(credentials: {
  username: string;
  password: string;
}): Promise<{ token: string; user: { username: string } }> {
  const res = await fetch('/api/admin/login', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(credentials),
  });
  const data = await res.json();
  if (!res.ok) {
    throw new Error(data.error || 'Invalid username or password.');
  }
  return data;
}

export async function adminLogout(): Promise<void> {
  try {
    await fetch('/api/admin/logout', {
      method: 'POST',
      headers: authHeaders(),
    });
  } finally {
    authStorage.clearToken();
  }
}

export async function checkAdminSession(): Promise<boolean> {
  const token = authStorage.getToken();
  if (!token) return false;
  try {
    const res = await fetch('/api/admin/me', {
      headers: authHeaders(),
    });
    return res.ok;
  } catch {
    return false;
  }
}

export async function fetchAdminStats(): Promise<DashboardStats> {
  const res = await fetch('/api/admin/stats', { headers: authHeaders() });
  if (!res.ok) throw new Error('Failed to load dashboard statistics');
  return res.json();
}

export async function fetchAdminSettings(): Promise<BusinessSettings> {
  const res = await fetch('/api/admin/settings', { headers: authHeaders() });
  if (!res.ok) throw new Error('Failed to load settings');
  return res.json();
}

export async function updateAdminSettings(settings: BusinessSettings): Promise<void> {
  const res = await fetch('/api/admin/settings', {
    method: 'PUT',
    headers: authHeaders(),
    body: JSON.stringify(settings),
  });
  if (!res.ok) {
    const err = await res.json();
    throw new Error(err.error || 'Failed to update settings');
  }
}

// Admin Fuel Prices
export async function fetchAdminFuelPrices(): Promise<FuelCategory[]> {
  const res = await fetch('/api/admin/fuel-prices', { headers: authHeaders() });
  if (!res.ok) throw new Error('Failed to load fuel prices');
  return res.json();
}

export async function createFuelCategory(data: Partial<FuelCategory>): Promise<void> {
  const res = await fetch('/api/admin/fuel-prices', {
    method: 'POST',
    headers: authHeaders(),
    body: JSON.stringify(data),
  });
  if (!res.ok) {
    const err = await res.json();
    throw new Error(err.error || 'Failed to add fuel category');
  }
}

export async function updateFuelCategory(id: number, data: Partial<FuelCategory>): Promise<void> {
  const res = await fetch(`/api/admin/fuel-prices/${id}`, {
    method: 'PUT',
    headers: authHeaders(),
    body: JSON.stringify(data),
  });
  if (!res.ok) {
    const err = await res.json();
    throw new Error(err.error || 'Failed to update fuel category');
  }
}

export async function deleteFuelCategory(id: number): Promise<void> {
  const res = await fetch(`/api/admin/fuel-prices/${id}`, {
    method: 'DELETE',
    headers: authHeaders(),
  });
  if (!res.ok) {
    const err = await res.json();
    throw new Error(err.error || 'Failed to delete fuel category');
  }
}

// Admin Services
export async function fetchAdminServices(): Promise<CustomerService[]> {
  const res = await fetch('/api/admin/services', { headers: authHeaders() });
  if (!res.ok) throw new Error('Failed to load services');
  return res.json();
}

export async function createCustomerService(data: Partial<CustomerService>): Promise<void> {
  const res = await fetch('/api/admin/services', {
    method: 'POST',
    headers: authHeaders(),
    body: JSON.stringify(data),
  });
  if (!res.ok) {
    const err = await res.json();
    throw new Error(err.error || 'Failed to create service');
  }
}

export async function updateCustomerService(id: number, data: Partial<CustomerService>): Promise<void> {
  const res = await fetch(`/api/admin/services/${id}`, {
    method: 'PUT',
    headers: authHeaders(),
    body: JSON.stringify(data),
  });
  if (!res.ok) {
    const err = await res.json();
    throw new Error(err.error || 'Failed to update service');
  }
}

export async function deleteCustomerService(id: number): Promise<void> {
  const res = await fetch(`/api/admin/services/${id}`, {
    method: 'DELETE',
    headers: authHeaders(),
  });
  if (!res.ok) {
    const err = await res.json();
    throw new Error(err.error || 'Failed to delete service');
  }
}

// Admin Gallery
export async function fetchAdminGallery(): Promise<GalleryImage[]> {
  const res = await fetch('/api/admin/gallery', { headers: authHeaders() });
  if (!res.ok) throw new Error('Failed to load gallery images');
  return res.json();
}

export async function uploadGalleryFile(file: File): Promise<string> {
  const formData = new FormData();
  formData.append('image', file);
  const token = authStorage.getToken();

  const res = await fetch('/api/admin/upload', {
    method: 'POST',
    headers: token ? { Authorization: `Bearer ${token}` } : {},
    body: formData,
  });

  const data = await res.json();
  if (!res.ok) throw new Error(data.error || 'File upload failed');
  return data.url;
}

export async function createGalleryImage(data: Partial<GalleryImage>): Promise<void> {
  const res = await fetch('/api/admin/gallery', {
    method: 'POST',
    headers: authHeaders(),
    body: JSON.stringify(data),
  });
  if (!res.ok) {
    const err = await res.json();
    throw new Error(err.error || 'Failed to create gallery image');
  }
}

export async function updateGalleryImage(id: number, data: Partial<GalleryImage>): Promise<void> {
  const res = await fetch(`/api/admin/gallery/${id}`, {
    method: 'PUT',
    headers: authHeaders(),
    body: JSON.stringify(data),
  });
  if (!res.ok) {
    const err = await res.json();
    throw new Error(err.error || 'Failed to update gallery image');
  }
}

export async function deleteGalleryImage(id: number): Promise<void> {
  const res = await fetch(`/api/admin/gallery/${id}`, {
    method: 'DELETE',
    headers: authHeaders(),
  });
  if (!res.ok) {
    const err = await res.json();
    throw new Error(err.error || 'Failed to delete gallery image');
  }
}

// Admin Feedback & Moderation
export async function fetchAdminFeedback(): Promise<FeedbackSubmission[]> {
  const res = await fetch('/api/admin/feedback', { headers: authHeaders() });
  if (!res.ok) throw new Error('Failed to load feedback');
  return res.json();
}

export async function updateFeedbackStatus(id: number, status: 'PENDING' | 'APPROVED' | 'REJECTED'): Promise<void> {
  const res = await fetch(`/api/admin/feedback/${id}/status`, {
    method: 'PUT',
    headers: authHeaders(),
    body: JSON.stringify({ status }),
  });
  if (!res.ok) {
    const err = await res.json();
    throw new Error(err.error || 'Failed to update feedback status');
  }
}

export async function deleteFeedbackSubmission(id: number): Promise<void> {
  const res = await fetch(`/api/admin/feedback/${id}`, {
    method: 'DELETE',
    headers: authHeaders(),
  });
  if (!res.ok) {
    const err = await res.json();
    throw new Error(err.error || 'Failed to delete feedback');
  }
}

// Admin Enquiries
export async function fetchAdminEnquiries(): Promise<CustomerEnquiry[]> {
  const res = await fetch('/api/admin/enquiries', { headers: authHeaders() });
  if (!res.ok) throw new Error('Failed to load enquiries');
  return res.json();
}

export async function updateEnquiryStatus(
  id: number,
  status: 'New' | 'In Progress' | 'Responded' | 'Resolved' | 'PENDING' | 'IN_PROGRESS' | 'RESOLVED',
  admin_notes?: string
): Promise<void> {
  const res = await fetch(`/api/admin/enquiries/${id}/status`, {
    method: 'PUT',
    headers: authHeaders(),
    body: JSON.stringify({ status, admin_notes }),
  });
  if (!res.ok) {
    const err = await res.json();
    throw new Error(err.error || 'Failed to update enquiry status');
  }
}


export async function deleteEnquiry(id: number): Promise<void> {
  const res = await fetch(`/api/admin/enquiries/${id}`, {
    method: 'DELETE',
    headers: authHeaders(),
  });
  if (!res.ok) {
    const err = await res.json();
    throw new Error(err.error || 'Failed to delete enquiry');
  }
}

// Admin Change Password
export async function changeAdminPassword(currentPassword: string, newPassword: string): Promise<void> {
  const res = await fetch('/api/admin/change-password', {
    method: 'PUT',
    headers: authHeaders(),
    body: JSON.stringify({ currentPassword, newPassword }),
  });
  if (!res.ok) {
    const err = await res.json();
    throw new Error(err.error || 'Failed to change password');
  }
}

// Admin Homepage Appearance
export async function fetchAdminAppearance(): Promise<HomepageAppearance> {
  const res = await fetch('/api/admin/appearance', { headers: authHeaders() });
  if (!res.ok) throw new Error('Failed to load homepage appearance');
  return res.json();
}

export async function updateAdminAppearance(data: Partial<HomepageAppearance>): Promise<void> {
  const res = await fetch('/api/admin/appearance', {
    method: 'PUT',
    headers: authHeaders(),
    body: JSON.stringify(data),
  });
  if (!res.ok) {
    const err = await res.json();
    throw new Error(err.error || 'Failed to update homepage appearance');
  }
}

export async function uploadAppearanceBackground(file: File): Promise<string> {
  const formData = new FormData();
  formData.append('image', file);
  const token = authStorage.getToken();

  const res = await fetch('/api/admin/appearance/upload', {
    method: 'POST',
    headers: token ? { Authorization: `Bearer ${token}` } : {},
    body: formData,
  });

  const data = await res.json();
  if (!res.ok) throw new Error(data.error || 'Background image upload failed');
  return data.url;
}

export async function deleteAppearanceBackground(): Promise<void> {
  const res = await fetch('/api/admin/appearance/image', {
    method: 'DELETE',
    headers: authHeaders(),
  });
  if (!res.ok) {
    const err = await res.json();
    throw new Error(err.error || 'Failed to delete background image');
  }
}

// Admin Announcements
export async function fetchAdminAnnouncements(): Promise<Announcement[]> {
  const res = await fetch('/api/admin/announcements', { headers: authHeaders() });
  if (!res.ok) throw new Error('Failed to load announcements');
  return res.json();
}

export async function createAdminAnnouncement(data: Partial<Announcement>): Promise<void> {
  const res = await fetch('/api/admin/announcements', {
    method: 'POST',
    headers: authHeaders(),
    body: JSON.stringify(data),
  });
  if (!res.ok) {
    const err = await res.json();
    throw new Error(err.error || 'Failed to create announcement');
  }
}

export async function updateAdminAnnouncement(id: number, data: Partial<Announcement>): Promise<void> {
  const res = await fetch(`/api/admin/announcements/${id}`, {
    method: 'PUT',
    headers: authHeaders(),
    body: JSON.stringify(data),
  });
  if (!res.ok) {
    const err = await res.json();
    throw new Error(err.error || 'Failed to update announcement');
  }
}

export async function deleteAdminAnnouncement(id: number): Promise<void> {
  const res = await fetch(`/api/admin/announcements/${id}`, {
    method: 'DELETE',
    headers: authHeaders(),
  });
  if (!res.ok) {
    const err = await res.json();
    throw new Error(err.error || 'Failed to delete announcement');
  }
}

// Admin Branding Settings & Logo
export async function fetchAdminBranding(): Promise<BrandingSettings> {
  const res = await fetch('/api/admin/branding', { headers: authHeaders() });
  if (!res.ok) throw new Error('Failed to load branding settings');
  return res.json();
}

export async function updateAdminBranding(data: Partial<BrandingSettings>): Promise<void> {
  const res = await fetch('/api/admin/branding', {
    method: 'PUT',
    headers: authHeaders(),
    body: JSON.stringify(data),
  });
  if (!res.ok) {
    const err = await res.json();
    throw new Error(err.error || 'Failed to update branding settings');
  }
}

export async function uploadAdminLogo(file: File): Promise<string> {
  const formData = new FormData();
  formData.append('image', file);
  const token = authStorage.getToken();

  const res = await fetch('/api/admin/branding/logo', {
    method: 'POST',
    headers: token ? { Authorization: `Bearer ${token}` } : {},
    body: formData,
  });

  const data = await res.json();
  if (!res.ok) throw new Error(data.error || 'Logo upload failed');
  return data.url;
}

export async function deleteAdminLogo(): Promise<void> {
  const res = await fetch('/api/admin/branding/logo', {
    method: 'DELETE',
    headers: authHeaders(),
  });
  if (!res.ok) {
    const err = await res.json();
    throw new Error(err.error || 'Failed to reset logo');
  }
}

// Upload service icon image
export async function uploadServiceIcon(file: File): Promise<string> {
  return uploadGalleryFile(file);
}

// ---------------------------------------------------------------------------
// HP PAY APP APIS
// ---------------------------------------------------------------------------
export async function fetchPublicHpPay(): Promise<HpPaySectionData | null> {
  const res = await fetch('/api/public/hp-pay');
  if (!res.ok) throw new Error('Failed to load HP Pay section');
  return res.json();
}

export async function fetchAdminHpPay(): Promise<HpPaySectionData> {
  const res = await fetch('/api/admin/hp-pay', { headers: authHeaders() });
  if (!res.ok) throw new Error('Failed to load HP Pay admin settings');
  return res.json();
}

export async function updateAdminHpPay(data: Partial<HpPaySectionData>): Promise<void> {
  const res = await fetch('/api/admin/hp-pay', {
    method: 'PUT',
    headers: authHeaders(),
    body: JSON.stringify(data),
  });
  if (!res.ok) {
    const err = await res.json();
    throw new Error(err.error || 'Failed to update HP Pay section');
  }
}

export async function deleteAdminHpPay(): Promise<void> {
  const res = await fetch('/api/admin/hp-pay', {
    method: 'DELETE',
    headers: authHeaders(),
  });
  if (!res.ok) {
    const err = await res.json();
    throw new Error(err.error || 'Failed to delete HP Pay section');
  }
}

export async function resetAdminHpPay(): Promise<void> {
  const res = await fetch('/api/admin/hp-pay/reset', {
    method: 'POST',
    headers: authHeaders(),
  });
  if (!res.ok) {
    const err = await res.json();
    throw new Error(err.error || 'Failed to reset HP Pay section');
  }
}

export async function uploadAdminHpPayIcon(file: File): Promise<string> {
  const formData = new FormData();
  formData.append('icon', file);
  const token = authStorage.getToken();

  const res = await fetch('/api/admin/hp-pay/icon', {
    method: 'POST',
    headers: token ? { Authorization: `Bearer ${token}` } : {},
    body: formData,
  });

  const data = await res.json();
  if (!res.ok) throw new Error(data.error || 'Icon upload failed');
  return data.url;
}

