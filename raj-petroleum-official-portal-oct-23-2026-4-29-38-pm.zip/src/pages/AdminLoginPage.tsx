import React, { useState } from 'react';
import { Eye, EyeOff, Lock, ArrowLeft } from 'lucide-react';
import { useNavigate } from 'react-router-dom';
import { adminLogin, authStorage } from '../api';

export const AdminLoginPage: React.FC = () => {
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [isLoading, setIsLoading] = useState(false);

  const navigate = useNavigate();

  const handleLogin = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!username.trim() || !password) {
      setError('Invalid username or password.');
      return;
    }

    setIsLoading(true);
    setError(null);

    try {
      const response = await adminLogin({
        username: username.trim(),
        password,
      });

      authStorage.setToken(response.token, true);
      navigate('/admin/dashboard');
    } catch (err: any) {
      setError('Invalid username or password.');
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-[#F3F6F9] flex flex-col justify-center items-center py-12 px-4 sm:px-6 lg:px-8">
      {/* Return to website link */}
      <div className="w-full max-w-md mb-6">
        <a
          href="/"
          className="inline-flex items-center gap-1.5 text-xs font-bold text-[#0756A5] hover:text-[#123B68] transition-colors"
        >
          <ArrowLeft className="w-4 h-4" />
          <span>Return to Raj Petroleum Public Website</span>
        </a>
      </div>

      <div className="w-full max-w-md bg-white rounded-2xl shadow-sm border border-slate-200 p-8">
        {/* Header Branding */}
        <div className="flex flex-col items-center mb-8">
          <div className="w-14 h-16 bg-white p-1 rounded-md mb-3 flex items-center justify-center">
            <img src="/assets/hp-logo.png" alt="Hindustan Petroleum" className="w-full h-full object-contain" />
          </div>
          <h2 className="text-xl font-black text-[#123B68] tracking-tight">
            Dealer Administration
          </h2>
          <span className="text-xs text-slate-500 font-medium mt-1">
            Raj Petroleum Management Portal
          </span>
        </div>

        {/* Error notification */}
        {error && (
          <div
            role="alert"
            className="mb-6 p-3.5 bg-rose-50 border border-rose-200 text-rose-800 rounded-lg text-xs font-semibold text-center"
          >
            {error}
          </div>
        )}

        {/* Form strictly complying with Rule 6:
            - Username input
            - Password input
            - Show/Hide Password button
            - Login button
        */}
        <form onSubmit={handleLogin} className="space-y-5" autoComplete="off">
          <div>
            <label
              htmlFor="admin-username"
              className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-1.5"
            >
              Username
            </label>
            <input
              id="admin-username"
              name="username"
              type="text"
              required
              autoFocus
              autoComplete="off"
              value={username}
              onChange={(e) => setUsername(e.target.value)}
              className="w-full px-4 py-2.5 text-sm bg-white border border-slate-300 rounded-lg focus:outline-hidden focus:border-[#0756A5] focus:ring-1 focus:ring-[#0756A5]"
            />
          </div>

          <div>
            <label
              htmlFor="admin-password"
              className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-1.5"
            >
              Password
            </label>
            <div className="relative">
              <input
                id="admin-password"
                name="password"
                type={showPassword ? 'text' : 'password'}
                required
                autoComplete="off"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                className="w-full px-4 py-2.5 text-sm bg-white border border-slate-300 rounded-lg pr-12 focus:outline-hidden focus:border-[#0756A5] focus:ring-1 focus:ring-[#0756A5]"
              />
              <button
                type="button"
                onClick={() => setShowPassword(!showPassword)}
                className="absolute inset-y-0 right-0 pr-3.5 flex items-center text-slate-400 hover:text-slate-600 focus:outline-hidden"
                aria-label={showPassword ? 'Hide password' : 'Show password'}
              >
                {showPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
              </button>
            </div>
          </div>

          <div className="pt-2">
            <button
              type="submit"
              disabled={isLoading}
              className="w-full inline-flex items-center justify-center gap-2 py-3 px-4 bg-[#0756A5] hover:bg-[#123B68] text-white text-xs font-bold uppercase tracking-wider rounded-lg shadow-sm hover:shadow transition-all disabled:opacity-50"
            >
              <Lock className="w-4 h-4" />
              <span>{isLoading ? 'Verifying...' : 'Log In'}</span>
            </button>
          </div>
        </form>
      </div>

      <div className="mt-8 text-center text-xs text-slate-400">
        <span>Authorized Personnel Only · Secure Session</span>
      </div>
    </div>
  );
};
