import React, { useEffect, useState, useCallback } from 'react';
import { AnnouncementBar } from '../components/AnnouncementBar';
import { Header } from '../components/Header';
import { Hero } from '../components/Hero';
import { LiveFuelPrice } from '../components/LiveFuelPrice';
import { About } from '../components/About';
import { Services } from '../components/Services';
import { Gallery } from '../components/Gallery';
import { HpPaySection } from '../components/HpPaySection';
import { FeedbackForm } from '../components/FeedbackForm';
import { CustomerReviews } from '../components/CustomerReviews';
import { EnquiryForm } from '../components/EnquiryForm';
import { FindUs } from '../components/FindUs';
import { ContactInfo } from '../components/ContactInfo';
import { Footer } from '../components/Footer';
import {
  fetchPublicSettings,
  fetchPublicAppearance,
  fetchPublicFuelPrices,
  fetchPublicServices,
  fetchPublicGallery,
  fetchPublicReviews,
  fetchPublicAnnouncements,
  fetchPublicBranding,
  fetchPublicHpPay,
} from '../api';
import {
  BusinessSettings,
  HomepageAppearance,
  FuelCategory,
  CustomerService,
  GalleryImage,
  CustomerReview,
  Announcement,
  BrandingSettings,
  HpPaySectionData,
} from '../types';

export const HomePage: React.FC = () => {
  const [settings, setSettings] = useState<BusinessSettings | null>(null);
  const [appearance, setAppearance] = useState<HomepageAppearance | null>(null);
  const [branding, setBranding] = useState<BrandingSettings | null>(null);
  const [announcements, setAnnouncements] = useState<Announcement[]>([]);
  const [fuelPrices, setFuelPrices] = useState<FuelCategory[]>([]);
  const [services, setServices] = useState<CustomerService[]>([]);
  const [gallery, setGallery] = useState<GalleryImage[]>([]);
  const [hpPay, setHpPay] = useState<HpPaySectionData | null>(null);
  const [reviews, setReviews] = useState<CustomerReview[]>([]);

  const [isLoadingPrices, setIsLoadingPrices] = useState(true);
  const [pricesError, setPricesError] = useState<string | null>(null);
  const [isLoadingServices, setIsLoadingServices] = useState(true);
  const [isLoadingGallery, setIsLoadingGallery] = useState(true);
  const [isLoadingReviews, setIsLoadingReviews] = useState(true);

  const [activeSection, setActiveSection] = useState('home');

  const loadFuelPrices = useCallback(async () => {
    try {
      setIsLoadingPrices(true);
      setPricesError(null);
      const data = await fetchPublicFuelPrices();
      setFuelPrices(data);
    } catch (err: any) {
      console.error('Failed to load fuel prices:', err);
      setPricesError(err.message || 'Unable to connect to live fuel tariff server.');
    } finally {
      setIsLoadingPrices(false);
    }
  }, []);

  const loadAllData = useCallback(async () => {
    // 1. Settings & Appearance
    fetchPublicSettings()
      .then(setSettings)
      .catch((err) => console.error('Failed to load settings:', err));

    fetchPublicAppearance()
      .then(setAppearance)
      .catch((err) => console.error('Failed to load appearance:', err));

    fetchPublicBranding()
      .then(setBranding)
      .catch((err) => console.error('Failed to load branding:', err));

    fetchPublicAnnouncements()
      .then(setAnnouncements)
      .catch((err) => console.error('Failed to load announcements:', err));

    // 2. Fuel prices
    loadFuelPrices();

    // 3. Services
    fetchPublicServices()
      .then(setServices)
      .catch((err) => console.error('Failed to load services:', err))
      .finally(() => setIsLoadingServices(false));

    // 4. Gallery
    fetchPublicGallery()
      .then(setGallery)
      .catch((err) => console.error('Failed to load gallery:', err))
      .finally(() => setIsLoadingGallery(false));

    // 5. Reviews
    fetchPublicReviews()
      .then(setReviews)
      .catch((err) => console.error('Failed to load reviews:', err))
      .finally(() => setIsLoadingReviews(false));

    // 6. HP Pay App Section
    fetchPublicHpPay()
      .then(setHpPay)
      .catch((err) => console.error('Failed to load HP Pay configuration:', err));
  }, [loadFuelPrices]);

  useEffect(() => {
    loadAllData();
  }, [loadAllData]);

  // Track active section on scroll for horizontal menu highlighting
  useEffect(() => {
    const sectionIds = [
      'home',
      'fuel-price',
      'about',
      'services',
      'gallery',
      'hp-pay',
      'feedback',
      'reviews',
      'support',
      'enquiry',
      'location',
      'contact',
    ];

    const observer = new IntersectionObserver(
      (entries) => {
        entries.forEach((entry) => {
          if (entry.isIntersecting) {
            setActiveSection(entry.target.id);
          }
        });
      },
      { threshold: 0.3 }
    );

    sectionIds.forEach((id) => {
      const el = document.getElementById(id);
      if (el) observer.observe(el);
    });

    return () => observer.disconnect();
  }, []);

  const isHpPayVisible = Boolean(hpPay && hpPay.is_visible !== 0 && hpPay.is_deleted !== 1);

  return (
    <div className="min-h-screen flex flex-col bg-[#FFFDF7] text-[#263238]">
      {/* 0. Top Announcement Bar */}
      <AnnouncementBar announcements={announcements} />

      {/* Header with full-width bar and single horizontal menu row */}
      <Header
        settings={settings}
        branding={branding}
        activeSection={activeSection}
        showHpPay={isHpPayVisible}
      />

      <main className="flex-1">
        {/* 1. Homepage Hero */}
        <Hero settings={settings} appearance={appearance} />

        {/* 2. Live Fuel Price */}
        <LiveFuelPrice
          fuelPrices={fuelPrices}
          isLoading={isLoadingPrices}
          error={pricesError}
          onRefresh={loadFuelPrices}
        />

        {/* 3. About Raj Petroleum */}
        <About settings={settings} />

        {/* 4. Customer Services */}
        <Services services={services} isLoading={isLoadingServices} />

        {/* 5. Station Gallery */}
        <Gallery images={gallery} isLoading={isLoadingGallery} />

        {/* 5b. HP Pay App Section - immediately after Station Gallery */}
        {isHpPayVisible && <HpPaySection hpPay={hpPay} />}

        {/* 6. Feedback Form */}
        <FeedbackForm />

        {/* 7. Customer Reviews */}
        <CustomerReviews reviews={reviews} isLoading={isLoadingReviews} />

        {/* 8. Enquiry Form */}
        <EnquiryForm />

        {/* 9. Find Raj Petroleum */}
        <FindUs settings={settings} />

        {/* 10. Contact Information */}
        <ContactInfo settings={settings} />
      </main>

      {/* 11. Footer */}
      <Footer settings={settings} branding={branding} />
    </div>
  );
};
